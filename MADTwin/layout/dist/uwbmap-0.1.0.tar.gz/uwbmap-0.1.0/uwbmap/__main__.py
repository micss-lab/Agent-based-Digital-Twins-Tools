import sys
from PyQt6 import QtWidgets
from uwbmap.mainwindow import MainWindow


def main():
    main_application = QtWidgets.QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(main_application.exec())


if __name__ == '__main__':
    main()
