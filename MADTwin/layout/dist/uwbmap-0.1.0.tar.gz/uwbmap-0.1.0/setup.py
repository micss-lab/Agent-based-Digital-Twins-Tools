# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['uwbmap',
 'uwbmap.agent',
 'uwbmap.mainwindow',
 'uwbmap.mainwindow.map',
 'uwbmap.matplot',
 'uwbmap.mqttclient',
 'uwbmap.pathsimilarity']

package_data = \
{'': ['*'], 'uwbmap': ['pictures/*']}

install_requires = \
['PyQt6>=6.2.3,<7.0.0',
 'PySide6>=6.4.1,<7.0.0',
 'matplotlib>=3.6.1,<4.0.0',
 'paho-mqtt>=1.6.1,<2.0.0',
 'py4j>=0.10.9,<0.11.0',
 'qtwidgets>=0.18,<0.19',
 'similaritymeasures>=0.6.0,<0.7.0']

entry_points = \
{'console_scripts': ['ampyfier = layout.uwbmap.__main__:__main__']}

setup_kwargs = {
    'name': 'uwbmap',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Ebert Schoofs',
    'author_email': 'ebertschoofs@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<3.11',
}


setup(**setup_kwargs)
